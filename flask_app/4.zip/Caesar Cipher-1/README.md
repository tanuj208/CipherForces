
# Algorithm Explanation

Given a key k, each character of the plaintext is circularly shifted by k steps.

Each character of the plaintext is assumed to be in lowercase alphabets.

# Problem Statement

Encrypted message = bzdrzqbhogdqhrsgdadrs
Find out the original message used.

# Access
You can look at the code but you do not have access to encryption or decryption server (with the same key value as in the problem).

# Solution
Frequency analysis or try out all keys and pick out the most probable solution.
caesarcipheristhebest
