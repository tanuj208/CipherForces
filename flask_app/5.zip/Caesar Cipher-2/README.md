
# Algorithm Explanation

Given a key k, each character of the plaintext is circularly shifted by k steps.

Each character of the plaintext is assumed to be in lowercase alphabets.

# Problem Statement

Original message = helloworld
Encrypted message = tqxxaiadxp
Find out the key used in the message.

# Access
You can look at the code but you do not have access to encryption or decryption server.

# Solution
value of key is 12